
(function() {
    "use strict";
    angular.module("deepin.store")
        .constant("CONFIG", {
            "self": {
                "endpoints": "/endpoints/v1",
                "data": "/data/v1",
            },
            "login": {
                "host": "https://login.deepin.org",
                "request_path": "/oauth2/authorize",
                "logout_path": "/oauth2/logout",
                "regions": {
                    "mainland": {
                        "client_id": "e6bf6f88dab14601e373d7805db086c848af1c74",
                    },
                    "international": {
                        "client_id": "724d30c2e51d4d86db9ef2602cd80da47c7e561d",
                    },
                    "professional": {
                        "client_id": "84de531dc0b6ba12f71061d53a955ecb06493558",
                    },
                },
            },
            "deepinid": {
                "host": "https://api.deepin.org",
            },
        });
})()
